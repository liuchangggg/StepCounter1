package com.mhv.stepcounter;
//author liu chang

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Main2Activity extends AppCompatActivity {

    private Button stepsButton;
    private Button stairsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        stepsButton = (Button) findViewById(R.id.stepsButton);
        stepsButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick (View v){
                openMainActivity();
            }
    });

        stairsButton = (Button) findViewById(R.id.stairsButton);
        stairsButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick (View v){
                openMainActivitys();
            }
        });

    }

    public void openMainActivity(){
        Intent intent = new Intent (this, MainActivity.class);
        startActivity(intent);

    }

    public void openMainActivitys(){
        Intent intent = new Intent (this, MainActivitys.class);
        startActivity(intent);

    }


}
