# StepCounter
Simple pedometer application using Android step detector, accelerometer and magnetometer sensors.

Step counter sensor was also tried but step detector turned out to work better in this case.

Device used for testing: Samsung Galaxy S5 running on Android Lollipop 5.0 (API level 21).

Min. SDK version supported: 19 (KitKat).

![alt text](screenshots/Screenshot_2016-03-16-15-11-19.png "Start")
![alt text](screenshots/Screenshot_2016-03-16-15-11-44.png "Counting")
![alt text](screenshots/Screenshot_2016-03-16-15-11-57.png "Settings")
![alt text](screenshots/Screenshot_2016-03-16-15-12-06.png "Record pick")
![alt text](screenshots/Screenshot_2016-03-16-15-20-18.png "Record achieved")

